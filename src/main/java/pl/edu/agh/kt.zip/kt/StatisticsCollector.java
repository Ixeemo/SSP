package pl.edu.agh.kt;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.projectfloodlight.openflow.protocol.OFFlowStatsEntry;
import org.projectfloodlight.openflow.protocol.OFFlowStatsReply;
import org.projectfloodlight.openflow.protocol.OFPortStatsEntry;
import org.projectfloodlight.openflow.protocol.OFPortStatsReply;
import org.projectfloodlight.openflow.protocol.OFStatsReply;
import org.projectfloodlight.openflow.protocol.OFStatsRequest;
import org.projectfloodlight.openflow.types.OFPort;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.google.common.util.concurrent.ListenableFuture;
import net.floodlightcontroller.core.IOFSwitch;
import java.util.HashMap;


public class StatisticsCollector {
	private static final Logger logger = LoggerFactory.getLogger(StatisticsCollector.class);
	private IOFSwitch sw;
	long first = 0;
	long second = 0;
	long diff = 0;
	int interval = 3;
	long thr = 0;
	private HashMap<Integer, Long> bytes = new HashMap<Integer, Long>();
	private HashMap<Integer, Long> both = new HashMap<Integer, Long>();
	public class PortStatisticsPoller extends TimerTask {
		private final Logger logger = LoggerFactory.getLogger(PortStatisticsPoller.class);
		@Override
		public void run() {
			logger.debug("run() begin");
			synchronized (StatisticsCollector.this) {
				if (sw == null) { // no switch
					logger.error("run() end (no switch)");
					return;
				}
				ListenableFuture<?> future;
				List<OFStatsReply> values = null;
				OFStatsRequest<?> req = null;
				OFStatsRequest<?> reqFlow = null;
				req = sw.getOFFactory().buildPortStatsRequest().setPortNo(OFPort.ANY).build();
				reqFlow = sw.getOFFactory().buildFlowStatsRequest().setOutPort(OFPort.ANY).build();
				//req = reqFlow;
				try {
					/*
					if (req != null) {
						future = sw.writeStatsRequest(req);
						values = (List<OFStatsReply>)
						future.get(PORT_STATISTICS_POLLING_INTERVAL * 1000 / 2, TimeUnit.MILLISECONDS);
					}
					OFPortStatsReply psr = (OFPortStatsReply) values.get(0);
					logger.info("Switch id: {}", sw.getId());
					for (OFPortStatsEntry pse : psr.getEntries()) {
						if (pse.getPortNo().getPortNumber() > 0) {
							logger.info("\tport number: {}, txPackets: {}",
									pse.getPortNo().getPortNumber(),
									pse.getTxPackets().getValue());
							bytes.put(pse.getPortNo().getPortNumber(), pse.getTxBytes().getValue());							
						}
					}
					for (Integer i: bytes.keySet()) {
						second =  bytes.get(i);
						if (both.get(i) != null) {
							first = both.get(i);
							diff = second - first;
							thr = diff/interval;
							logger.info("\tThroughput: {}", thr);
						}
						first = bytes.get(i);
						both.put(i, first);
					}
					*/
					if (reqFlow != null) {
						future = sw.writeStatsRequest(reqFlow);
						values = (List<OFStatsReply>)
						future.get(PORT_STATISTICS_POLLING_INTERVAL * 1000 / 2, TimeUnit.MILLISECONDS);
					}
					OFFlowStatsReply psr = (OFFlowStatsReply) values.get(0);
					logger.info("Switch id: {}", sw.getId());
					logger.info("XID: {}", psr.getXid());

					for (OFFlowStatsEntry pse : psr.getEntries()) {
						logger.info("\tFlow Info:", pse.toString());
						
					}
					for (Integer i: bytes.keySet()) {
						second =  bytes.get(i);
						if (both.get(i) != null) {
							first = both.get(i);
							diff = second - first;
							thr = diff/interval;
							logger.info("\tThroughput: {}", thr);
						}
						first = bytes.get(i);
						both.put(i, first);
					}
				} catch (InterruptedException | ExecutionException | TimeoutException ex) {
					logger.error("Error during statistics polling", ex);
				}
			}
			logger.debug("run() end");
		}
	}

	public static final int PORT_STATISTICS_POLLING_INTERVAL = 3000; // in ms
	private static StatisticsCollector singleton;
	private StatisticsCollector(IOFSwitch sw) {
		this.sw = sw;
		new Timer().scheduleAtFixedRate(new PortStatisticsPoller(), 0,
				PORT_STATISTICS_POLLING_INTERVAL);
	}
	public static StatisticsCollector getInstance(IOFSwitch sw) {
		logger.debug("getInstance() begin");
		synchronized (StatisticsCollector.class) {
			if (singleton == null) {
				logger.debug("Creating StatisticsCollector singleton");
				singleton = new StatisticsCollector(sw);
			}
		}
		logger.debug("getInstance() end");
		return singleton;
	}
}